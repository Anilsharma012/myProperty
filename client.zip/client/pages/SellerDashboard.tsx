import React from 'react';
import IntegratedSellerDashboard from '../components/IntegratedSellerDashboard';

const SellerDashboard: React.FC = () => {
  return <IntegratedSellerDashboard />;
};

export default SellerDashboard;
